"""
app.py - Streamlit web app: Resume & Job Description Matching System.

Run:  streamlit run app.py
"""
import json
from pathlib import Path

import pandas as pd
import streamlit as st

from src.evaluate import evaluate_methods, load_human_rankings
from src.extract import extract_cached, extract_jd, extract_resume, profiles_to_csv_rows
from src.io_utils import load_folder, read_text_from_bytes
from src.llm import llm_available
from src.ranking import CandidateRanker
from src.schema import JobProfile, ResumeProfile
from src.skill_gap import generate_skill_gap_report, report_to_markdown

ROOT = Path(__file__).resolve().parent
st.set_page_config(page_title="Resume-JD Matcher", page_icon="🎯", layout="wide")

METHOD_LABELS = {"hybrid": "Hybrid (SBERT + skill match)", "sbert": "Contextual - SBERT (ChromaDB)",
                 "glove": "Static - GloVe"}

# --------------------------------------------------------------------------- sidebar
with st.sidebar:
    st.title("🎯 Resume ↔ JD Matcher")
    st.caption("PES University · Mini Project · Problem Statement 4")
    if llm_available():
        st.success("LLM: Groq connected")
    else:
        st.warning("LLM: offline mode (rule-based). Add GROQ_API_KEY in .streamlit/secrets.toml to enable the LLM.")
    use_llm = st.toggle("Use LLM for extraction & reports", value=llm_available(), disabled=not llm_available())
    st.divider()
    method = st.radio("Ranking method", list(METHOD_LABELS), format_func=METHOD_LABELS.get)
    top_k = st.slider("Shortlist size (top-k)", 3, 10, 5)


# --------------------------------------------------------------------------- data helpers
@st.cache_data(show_spinner=False)
def sample_texts(kind: str):
    return load_folder(ROOT / "data" / kind)


@st.cache_data(show_spinner="Extracting structured profiles ...")
def sample_profiles(kind: str, use_llm: bool):
    return {k: extract_cached(kind, k, t, use_llm).model_dump() for k, t in sample_texts(kind).items()}


@st.cache_resource(show_spinner="Embedding candidates into ChromaDB ...")
def get_ranker(pool_json: str):
    pool = {k: ResumeProfile.model_validate(v) for k, v in json.loads(pool_json).items()}
    return CandidateRanker(pool)


if "uploaded" not in st.session_state:
    st.session_state.uploaded = {}      # id -> ResumeProfile dict (resumes uploaded in this session)

resumes = sample_profiles("resumes", use_llm)
jds = sample_profiles("jds", use_llm)
pool = {**resumes, **st.session_state.uploaded}

tab1, tab2, tab3, tab4 = st.tabs(["1️⃣ Extract", "2️⃣ Rank candidates", "3️⃣ Skill-gap report", "4️⃣ Evaluation (NDCG@5)"])

# --------------------------------------------------------------------------- TAB 1: extraction
with tab1:
    st.subheader("Structured-output extraction → fixed JSON schema")
    kind = st.radio("Document type", ["Resume", "Job description"], horizontal=True)
    src = st.radio("Source", ["Sample file", "Upload (PDF / DOCX / TXT)", "Paste text"], horizontal=True)
    folder = "resumes" if kind == "Resume" else "jds"
    text = ""
    if src == "Sample file":
        key = st.selectbox("Choose sample", list(sample_texts(folder)))
        text = sample_texts(folder)[key]
    elif src.startswith("Upload"):
        f = st.file_uploader("Upload file", type=["pdf", "docx", "txt"], key=f"up_{folder}")
        if f:
            text = read_text_from_bytes(f.getvalue(), f.name)
    else:
        text = st.text_area("Paste text", height=250)

    c1, c2 = st.columns(2)
    with c1:
        st.markdown("**Raw text**")
        st.text_area("raw", text, height=420, label_visibility="collapsed", disabled=True)
    with c2:
        st.markdown("**Extracted JSON**")
        if st.button("Extract", type="primary", disabled=not text.strip()):
            with st.spinner("Extracting ..."):
                prof, mode = (extract_resume if kind == "Resume" else extract_jd)(text, use_llm=use_llm)
            st.session_state.last_extract = (prof, mode, kind)
        if "last_extract" in st.session_state and st.session_state.last_extract[2] == kind:
            prof, mode, _ = st.session_state.last_extract
            st.caption(f"Extraction mode: **{mode}**")
            st.json(prof.model_dump())
            st.download_button("Download JSON", prof.model_dump_json(indent=2), "extracted.json", "application/json")
            if kind == "Resume":
                if st.button("➕ Add this resume to the candidate pool"):
                    st.session_state.uploaded[f"upload_{len(st.session_state.uploaded) + 1}"] = prof.model_dump()
                    st.success(f"Added {prof.name}. Go to 'Rank candidates'.")
                    st.rerun()

    st.divider()
    st.markdown("**Export all candidate profiles**")
    rows = profiles_to_csv_rows([ResumeProfile.model_validate(v) for v in pool.values()])
    st.download_button("Download all resumes as CSV", pd.DataFrame(rows).to_csv(index=False), "candidates.csv", "text/csv")
    st.download_button("Download all resumes as JSON", json.dumps(pool, indent=2), "candidates.json", "application/json")

# --------------------------------------------------------------------------- TAB 2: ranking
with tab2:
    st.subheader("Rank candidates for a job")
    jd_src = st.radio("Job description", ["Sample JD", "Paste / upload new JD"], horizontal=True)
    if jd_src == "Sample JD":
        jd_key = st.selectbox("Choose job", list(jds), format_func=lambda k: jds[k]["title"])
        jd = JobProfile.model_validate(jds[jd_key])
    else:
        jd_key = None
        f = st.file_uploader("Upload JD", type=["pdf", "docx", "txt"], key="jd_rank_up")
        t = read_text_from_bytes(f.getvalue(), f.name) if f else st.text_area("Paste JD text", height=180)
        jd = extract_jd(t, use_llm=use_llm)[0] if t and t.strip() else None

    if jd:
        with st.expander("Job requirements (extracted)", expanded=False):
            st.write(f"**{jd.title}** · {jd.company} · min {jd.min_experience_years} yrs")
            st.write("Required:", ", ".join(jd.required_skills))
            st.write("Preferred:", ", ".join(jd.preferred_skills))

        ranker = get_ranker(json.dumps(pool, sort_keys=True))
        ranked = ranker.rank(jd, method=method)
        st.session_state.ranked, st.session_state.jd = ranked, jd
        st.caption(f"{len(pool)} candidates · method: **{METHOD_LABELS[method]}**")

        df = pd.DataFrame([{
            "Rank": r["rank"], "Candidate": r["name"], "Score": r["score"],
            "Semantic sim.": r["semantic_similarity"], "Skill match": r["skill_match"],
            "Exp (yrs)": r["experience_years"],
            "Missing required": ", ".join(r["missing_required"]) or "—"} for r in ranked])
        st.dataframe(df.head(top_k), hide_index=True, width="stretch")
        st.bar_chart(df.head(top_k).set_index("Candidate")["Score"])

        with st.expander("Compare all three methods (top-5)"):
            cols = st.columns(3)
            human = load_human_rankings().get(jd_key, {}) if jd_key else {}
            for col, m in zip(cols, ["glove", "sbert", "hybrid"]):
                col.markdown(f"**{METHOD_LABELS[m]}**")
                try:
                    top5 = ranker.rank(jd, method=m)[:5]
                except Exception as e:
                    col.error(f"Could not run {m}: {type(e).__name__}. Check the internet connection (first run downloads the models).")
                    continue
                for r in top5:
                    g = f" (human grade {human.get(r['id'], 0)})" if human else ""
                    col.write(f"{r['rank']}. {r['name']} — {r['score']:.3f}{g}")

        with st.expander("Full ranking"):
            st.dataframe(df, hide_index=True, width="stretch")

# --------------------------------------------------------------------------- TAB 3: skill gap
with tab3:
    st.subheader("Skill-gap analysis & recommendations (prompt chain)")
    if "ranked" not in st.session_state:
        st.info("Rank candidates in tab 2 first.")
    else:
        jd = st.session_state.jd
        short = st.session_state.ranked[:top_k]
        names = {r["id"]: f"#{r['rank']} {r['name']} ({r['score']:.2f})" for r in short}
        chosen = st.multiselect("Shortlisted candidates", list(names), default=list(names)[:2], format_func=names.get)
        if st.button("Generate skill-gap reports", type="primary", disabled=not chosen):
            for cid in chosen:
                with st.spinner(f"Analysing {pool[cid]['name']} ..."):
                    rep, mode = generate_skill_gap_report(ResumeProfile.model_validate(pool[cid]), jd, use_llm=use_llm)
                with st.container(border=True):
                    st.caption(f"generated in **{mode}** mode")
                    md = report_to_markdown(rep)
                    st.markdown(md)
                    st.download_button("Download report (.md)", md, f"skill_gap_{cid}.md", key=f"dl_{cid}")

# --------------------------------------------------------------------------- TAB 4: evaluation
with tab4:
    st.subheader("Static vs contextual embeddings — NDCG@5 against human rankings")
    st.latex(r"NDCG@5=\frac{\sum_{i=1}^{5}\frac{2^{rel_i}-1}{\log_2(i+1)}}{IDCG@5}")
    st.caption("rel_i = human relevance grade (0-3) of the candidate the system placed at rank i. "
               "IDCG = DCG of the perfect (human) ordering.")
    if st.button("Run evaluation", type="primary"):
        with st.spinner("Ranking every job with GloVe, SBERT and Hybrid ..."):
            r_pool = {k: ResumeProfile.model_validate(v) for k, v in resumes.items()}
            r_jds = {k: JobProfile.model_validate(v) for k, v in jds.items()}
            try:
                per_jd, summary = evaluate_methods(get_ranker(json.dumps(resumes, sort_keys=True)), r_jds, load_human_rankings())
            except Exception as e:
                st.error(f"Evaluation failed ({type(e).__name__}). Check the internet connection and try again.")
                st.stop()
        s = pd.DataFrame(summary)
        st.dataframe(s, hide_index=True)
        p = pd.DataFrame(per_jd)
        st.bar_chart(p.pivot(index="job", columns="method", values="NDCG@5")[["glove", "sbert", "hybrid"]], stack=False)
        st.dataframe(p, hide_index=True, width="stretch")
    with st.expander("Human relevance grades used as ground truth"):
        h = load_human_rankings()
        grid = pd.DataFrame({jd_id: {cid: h[jd_id].get(cid, 0) for cid in resumes} for jd_id in h})
        st.dataframe(grid, width="stretch")
