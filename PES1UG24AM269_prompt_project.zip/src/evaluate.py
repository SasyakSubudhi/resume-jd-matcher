"""
evaluate.py - NDCG@5 evaluation of the ranking methods against human rankings.

NDCG@k (Normalised Discounted Cumulative Gain):
    DCG@k  = sum_{i=1..k} (2^rel_i - 1) / log2(i + 1)
    IDCG@k = DCG@k of the IDEAL ordering (human grades sorted high -> low)
    NDCG@k = DCG@k / IDCG@k        (1.0 = perfect ranking, 0 = useless)

rel_i is the human relevance grade (0-3) of the candidate the system put at
position i. Highly relevant candidates near the top count the most.
"""
import json
import math
from pathlib import Path
from typing import Dict, List

HUMAN_PATH = Path(__file__).resolve().parent.parent / "data" / "human_rankings.json"


def load_human_rankings(path=HUMAN_PATH) -> Dict[str, Dict[str, int]]:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    return {k: v for k, v in data.items() if not k.startswith("_")}


def dcg_at_k(rels: List[float], k: int) -> float:
    return sum((2 ** r - 1) / math.log2(i + 2) for i, r in enumerate(rels[:k]))


def ndcg_at_k(ranked_ids: List[str], grades: Dict[str, int], k: int = 5) -> float:
    rels = [grades.get(cid, 0) for cid in ranked_ids]
    ideal = sorted(grades.values(), reverse=True)
    idcg = dcg_at_k(ideal, k)
    return dcg_at_k(rels, k) / idcg if idcg > 0 else 0.0


def precision_at_k(ranked_ids: List[str], grades: Dict[str, int], k: int = 5, threshold: int = 2) -> float:
    """Share of the top-k that humans graded as a good fit (grade >= threshold)."""
    return sum(grades.get(c, 0) >= threshold for c in ranked_ids[:k]) / k


def evaluate_methods(ranker, jds: Dict, human: Dict[str, Dict[str, int]],
                     methods=("glove", "sbert", "hybrid"), k: int = 5):
    """Returns (per_jd_rows, summary_rows) ready for a pandas DataFrame."""
    per_jd, summary = [], []
    for m in methods:
        scores, precs = [], []
        for jd_id, jd in jds.items():
            if jd_id not in human:
                continue
            ranked = [r["id"] for r in ranker.rank(jd, method=m)]
            n = ndcg_at_k(ranked, human[jd_id], k)
            p = precision_at_k(ranked, human[jd_id], k)
            scores.append(n)
            precs.append(p)
            per_jd.append({"method": m, "job": jd_id, f"NDCG@{k}": round(n, 4),
                           f"P@{k}": round(p, 2), f"top{k}": ", ".join(ranked[:k])})
        summary.append({"method": m, f"mean NDCG@{k}": round(sum(scores) / len(scores), 4),
                        f"mean P@{k}": round(sum(precs) / len(precs), 3)})
    return per_jd, summary
